#!/bin/bash
#
#

arq="/var/log/snmptrap/snmptrap.log"


	# Verificar se arquivo existe
	[ -e "$arq" ] || {

		# Criar o cabeçalho padrão do JSON
        	printf "{";
        	printf "\"data\":[";

		# Finaliza o Formato JSON
        	printf "]";
     		printf "}";
		
		exit 0;
	}
	
	PRIMEIRO_ELEMENTO=1

	jobs=$(grep "31023.1.1.102" "$arq" |cut -d\" -f2|sort -u)

	# Criar o cabeçalho padrão do JSON
	printf "{";
	printf "\"data\":[";

        IFS=$'\n'

		for jobs_veem in $jobs
		do
			# Verifica o primeiro elemento
			 if [ $PRIMEIRO_ELEMENTO -ne 1 ]; then
			   	 printf ","
			 fi
	          	
                         # Não coloca "," caso seja o ultimo dado no JSON
		         PRIMEIRO_ELEMENTO=0

			 # Cria o JSON de cada jobs
			 printf "{"
			 printf "\"{#JOBSVEEM}\":\"$jobs_veem\""
			 printf "}"

	        done
	# Finaliza o Formato JSON
	printf "]";
	printf "}";

       # Encerra
       exit 0;

